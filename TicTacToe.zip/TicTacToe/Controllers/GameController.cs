﻿using Microsoft.AspNetCore.Mvc;
using TicTacToe.Models;

namespace TicTacToe.Controllers
{
    public class GameController : Controller
    {
        private static GameModel _game = new GameModel();
        private static bool isAIEnabled = false;

        public IActionResult Index()
        {
            return View(_game);
        }

        public IActionResult SetMode(bool aiMode)
        {
            isAIEnabled = aiMode;
            _game = new GameModel();
            return RedirectToAction("Index");
        }

        public IActionResult MakeMove(int row, int col)
        {
            if (_game.MakeMove(row, col))
            {
                if (isAIEnabled && _game.CurrentPlayer == 'O')
                {
                    AIMove();
                }
            }
            return RedirectToAction("Index");
        }

        private void AIMove()
        {
            var aiMove = _game.GetAIMove();
            if (aiMove.HasValue) 
            {
                _game.MakeMove(aiMove.Value.Item1, aiMove.Value.Item2);
            }
        }


        public IActionResult Reset()
        {
            _game = new GameModel();
            return RedirectToAction("Index");
        }
    }
}